import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Upload,
  X,
  Plus,
  Instagram,
  Youtube,
  Twitter,
  Globe,
  MapPin,
  DollarSign,
  Camera,
  Users,
  ArrowLeft,
} from "lucide-react";
import { useState } from "react";

export default function CreateProfile() {
  const [selectedNiches, setSelectedNiches] = useState<string[]>([]);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);

  const niches = [
    "fashion",
    "beauty",
    "lifestyle",
    "fitness",
    "food",
    "travel",
    "tech",
    "business",
    "parenting",
    "home",
    "art",
    "music",
    "gaming",
    "sports",
    "health",
    "education",
  ];

  const addNiche = (niche: string) => {
    if (!selectedNiches.includes(niche) && selectedNiches.length < 5) {
      setSelectedNiches([...selectedNiches, niche]);
    }
  };

  const removeNiche = (niche: string) => {
    setSelectedNiches(selectedNiches.filter((n) => n !== niche));
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#cbf5dd" }}>
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                back
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                  <Users className="w-3 h-3 text-white" />
                </div>
                <span className="font-medium">InfluenceHub</span>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                save draft
              </Button>
              <Button
                size="sm"
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700"
              >
                publish profile
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-light text-black mb-2">
            create your profile
          </h1>
          <p className="text-gray-600">
            showcase your work and connect with brands that align with your
            values
          </p>
        </div>

        <div className="space-y-8">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">
                basic information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="firstName" className="text-sm text-gray-600">
                    first name
                  </Label>
                  <Input
                    id="firstName"
                    placeholder="Enter your first name"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName" className="text-sm text-gray-600">
                    last name
                  </Label>
                  <Input
                    id="lastName"
                    placeholder="Enter your last name"
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email" className="text-sm text-gray-600">
                  email address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  className="mt-1"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="location" className="text-sm text-gray-600">
                    location
                  </Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="location"
                      placeholder="City, Country"
                      className="pl-10 mt-1"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="timezone" className="text-sm text-gray-600">
                    timezone
                  </Label>
                  <Select>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pst">Pacific Standard Time</SelectItem>
                      <SelectItem value="est">Eastern Standard Time</SelectItem>
                      <SelectItem value="cst">Central Standard Time</SelectItem>
                      <SelectItem value="mst">
                        Mountain Standard Time
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="bio" className="text-sm text-gray-600">
                  bio
                </Label>
                <Textarea
                  id="bio"
                  placeholder="Tell brands about yourself, your style, and what makes you unique..."
                  className="mt-1"
                  rows={4}
                />
                <p className="text-xs text-gray-500 mt-1">0/500 characters</p>
              </div>
            </CardContent>
          </Card>

          {/* Profile Picture & Portfolio */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">
                profile picture & portfolio
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-sm text-gray-600">profile picture</Label>
                <div className="mt-2 flex items-center space-x-4">
                  <div
                    className="w-20 h-20 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: "#cbf5dd" }}
                  >
                    <Camera className="w-8 h-8 text-gray-400" />
                  </div>
                  <Button variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    upload photo
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  recommended: square image, at least 400x400px
                </p>
              </div>

              <Separator />

              <div>
                <Label className="text-sm text-gray-600">
                  portfolio images
                </Label>
                <div className="mt-2">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    {uploadedImages.map((image, index) => (
                      <div key={index} className="relative group">
                        <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                          <img
                            src={image}
                            alt={`Portfolio ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="absolute top-1 right-1 w-6 h-6 p-0 bg-white rounded-full opacity-0 group-hover:opacity-100"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                    <div className="aspect-square border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center cursor-pointer hover:border-gray-400 transition-colors">
                      <div className="text-center">
                        <Plus className="w-6 h-6 text-gray-400 mx-auto mb-2" />
                        <p className="text-xs text-gray-500">add image</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">
                    upload up to 12 images that showcase your best work
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Niches & Categories */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">
                niches & categories
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-sm text-gray-600">
                  select your niches (up to 5)
                </Label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {selectedNiches.map((niche) => (
                    <Badge
                      key={niche}
                      className="bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700 cursor-pointer"
                      onClick={() => removeNiche(niche)}
                    >
                      {niche}
                      <X className="w-3 h-3 ml-1" />
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm text-gray-600">
                  available niches
                </Label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {niches
                    .filter((niche) => !selectedNiches.includes(niche))
                    .map((niche) => (
                      <Badge
                        key={niche}
                        variant="outline"
                        className="cursor-pointer hover:bg-gray-100"
                        onClick={() => addNiche(niche)}
                      >
                        {niche}
                        <Plus className="w-3 h-3 ml-1" />
                      </Badge>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Social Media */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">
                social media accounts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4">
                <div>
                  <Label className="text-sm text-gray-600 flex items-center">
                    <Instagram className="w-4 h-4 mr-2" />
                    instagram
                  </Label>
                  <div className="mt-1 grid grid-cols-2 gap-4">
                    <Input placeholder="@username" />
                    <Input placeholder="followers count" type="number" />
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-600 flex items-center">
                    <Youtube className="w-4 h-4 mr-2" />
                    youtube
                  </Label>
                  <div className="mt-1 grid grid-cols-2 gap-4">
                    <Input placeholder="channel name" />
                    <Input placeholder="subscribers count" type="number" />
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-600 flex items-center">
                    <Twitter className="w-4 h-4 mr-2" />
                    twitter/x
                  </Label>
                  <div className="mt-1 grid grid-cols-2 gap-4">
                    <Input placeholder="@username" />
                    <Input placeholder="followers count" type="number" />
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-600 flex items-center">
                    <Globe className="w-4 h-4 mr-2" />
                    website/blog
                  </Label>
                  <Input
                    placeholder="https://yourwebsite.com"
                    className="mt-1"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pricing */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">pricing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm text-gray-600">
                    instagram post
                  </Label>
                  <div className="relative mt-1">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input placeholder="500" className="pl-10" />
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-600">
                    instagram story
                  </Label>
                  <div className="relative mt-1">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input placeholder="200" className="pl-10" />
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-600">youtube video</Label>
                  <div className="relative mt-1">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input placeholder="1000" className="pl-10" />
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-sm text-gray-600">
                  custom package pricing
                </Label>
                <Textarea
                  placeholder="Describe your custom packages, long-term collaboration rates, or special services..."
                  className="mt-1"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="flex justify-end space-x-4">
            <Button variant="outline">save as draft</Button>
            <Button className="bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700">
              publish profile
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
