import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Search,
  Users,
  Star,
  TrendingUp,
  Instagram,
  Youtube,
  Camera,
  Filter,
  ArrowRight,
  Globe,
  Heart,
  MessageCircle,
  Verified,
  MapPin,
  DollarSign,
  Eye,
} from "lucide-react";

export default function Index() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="border-b border-gray-100 sticky top-0 bg-white/95 backdrop-blur-sm z-50">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                <Users className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-medium text-black">
                InfluenceHub
              </span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <a
                href="#discover"
                className="text-gray-600 hover:text-black transition-colors text-sm"
              >
                discover
              </a>
              <a
                href="#how-it-works"
                className="text-gray-600 hover:text-black transition-colors text-sm"
              >
                how it works
              </a>
              <a
                href="#pricing"
                className="text-gray-600 hover:text-black transition-colors text-sm"
              >
                pricing
              </a>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600">
                log in
              </Button>
              <Button
                size="sm"
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700"
                onClick={() => (window.location.href = "/create-profile")}
              >
                join as influencer
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <Badge
            className="mb-6 text-gray-700 hover:opacity-90"
            style={{ backgroundColor: "#cbf5dd" }}
          >
            <TrendingUp className="w-3 h-3 mr-1" />
            10,000+ verified influencers
          </Badge>

          <h1 className="text-4xl lg:text-6xl font-light text-black mb-8 leading-tight max-w-4xl mx-auto">
            connect with
            <br />
            <span className="font-medium">authentic creators</span>
          </h1>

          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed">
            The platform where brands discover verified influencers and creators
            showcase their authentic work. Join thousands of successful
            collaborations.
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative flex items-center">
              <Search className="absolute left-4 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search by niche, location, or follower count..."
                className="pl-12 pr-20 h-14 text-base border-gray-200 focus:border-black"
              />
              <Button
                size="sm"
                className="absolute right-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700"
              >
                search
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-md mx-auto">
            <div className="text-center">
              <div className="text-2xl font-light text-black">10K+</div>
              <div className="text-sm text-gray-500">creators</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-light text-black">500+</div>
              <div className="text-sm text-gray-500">brands</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-light text-black">100M+</div>
              <div className="text-sm text-gray-500">reach</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Influencers */}
      <section
        id="discover"
        className="py-20"
        style={{ backgroundColor: "#cbf5dd" }}
      >
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-2xl font-light text-black mb-2">
                featured creators
              </h2>
              <p className="text-gray-600">
                discover top-performing influencers across all niches
              </p>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" className="border-gray-300">
                <Filter className="w-4 h-4 mr-2" />
                filters
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                view all
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Influencer Card 1 */}
            <Card className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
              <CardContent className="p-0">
                <div className="relative">
                  <div className="aspect-square bg-gray-100 overflow-hidden rounded-t-lg">
                    <img
                      src="https://images.pexels.com/photos/32720828/pexels-photo-32720828.jpeg"
                      alt="Sophia Miller"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <Badge className="absolute top-4 left-4 bg-white text-gray-900">
                    <Verified className="w-3 h-3 mr-1 text-blue-500" />
                    verified
                  </Badge>
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 text-xs font-medium">
                    4.9 ⭐
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-medium text-lg">Sophia Miller</h3>
                      <p className="text-sm text-gray-500 flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        Los Angeles, CA
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">2.1M</div>
                      <div className="text-xs text-gray-500">followers</div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="secondary" className="text-xs">
                      fashion
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      lifestyle
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      beauty
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <Instagram className="w-4 h-4 mr-1" />
                        2.1M
                      </span>
                      <span className="flex items-center">
                        <Youtube className="w-4 h-4 mr-1" />
                        890K
                      </span>
                    </div>
                    <div className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-1" />
                      <span>$2K - $5K</span>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700">
                    view profile
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Influencer Card 2 */}
            <Card className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
              <CardContent className="p-0">
                <div className="relative">
                  <div className="aspect-square bg-gray-100 overflow-hidden rounded-t-lg">
                    <img
                      src="https://images.pexels.com/photos/32744391/pexels-photo-32744391.jpeg"
                      alt="Emma Chen"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <Badge className="absolute top-4 left-4 bg-white text-gray-900">
                    <Verified className="w-3 h-3 mr-1 text-blue-500" />
                    verified
                  </Badge>
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 text-xs font-medium">
                    4.8 ⭐
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-medium text-lg">Emma Chen</h3>
                      <p className="text-sm text-gray-500 flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        New York, NY
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">1.5M</div>
                      <div className="text-xs text-gray-500">followers</div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="secondary" className="text-xs">
                      tech
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      business
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      travel
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <Instagram className="w-4 h-4 mr-1" />
                        1.5M
                      </span>
                      <span className="flex items-center">
                        <Youtube className="w-4 h-4 mr-1" />
                        650K
                      </span>
                    </div>
                    <div className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-1" />
                      <span>$1.5K - $3K</span>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700">
                    view profile
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Influencer Card 3 */}
            <Card className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
              <CardContent className="p-0">
                <div className="relative">
                  <div className="aspect-square bg-gray-100 overflow-hidden rounded-t-lg">
                    <img
                      src="https://images.pexels.com/photos/6919949/pexels-photo-6919949.jpeg"
                      alt="Marcus Johnson"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <Badge className="absolute top-4 left-4 bg-white text-gray-900">
                    <Verified className="w-3 h-3 mr-1 text-blue-500" />
                    verified
                  </Badge>
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 text-xs font-medium">
                    4.7 ⭐
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-medium text-lg">Marcus Johnson</h3>
                      <p className="text-sm text-gray-500 flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        Miami, FL
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">980K</div>
                      <div className="text-xs text-gray-500">followers</div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="secondary" className="text-xs">
                      fitness
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      health
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      nutrition
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <Instagram className="w-4 h-4 mr-1" />
                        980K
                      </span>
                      <span className="flex items-center">
                        <Youtube className="w-4 h-4 mr-1" />
                        420K
                      </span>
                    </div>
                    <div className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-1" />
                      <span>$800 - $2K</span>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700">
                    view profile
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-light text-black mb-4">
              how it works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              simple steps to connect brands with authentic creators
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            {/* For Influencers */}
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Camera className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-medium mb-4">for creators</h3>
              <div className="space-y-3 text-gray-600 text-sm">
                <p>1. Create your profile</p>
                <p>2. Upload your portfolio</p>
                <p>3. Set your rates</p>
                <p>4. Get discovered by brands</p>
              </div>
            </div>

            {/* For Brands */}
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-medium mb-4">for brands</h3>
              <div className="space-y-3 text-gray-600 text-sm">
                <p>1. Search our database</p>
                <p>2. Filter by niche & metrics</p>
                <p>3. Review portfolios</p>
                <p>4. Connect directly</p>
              </div>
            </div>

            {/* Results */}
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-medium mb-4">results</h3>
              <div className="space-y-3 text-gray-600 text-sm">
                <p>1. Authentic partnerships</p>
                <p>2. Successful campaigns</p>
                <p>3. Measurable ROI</p>
                <p>4. Long-term growth</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20" style={{ backgroundColor: "#cbf5dd" }}>
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-light text-black mb-4">
            ready to get started?
          </h2>
          <p className="text-xl text-gray-600 mb-12">
            join thousands of creators and brands building authentic connections
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 border-2 border-black">
              <h3 className="text-xl font-medium mb-4">for influencers</h3>
              <p className="text-gray-600 mb-6">
                showcase your work, connect with brands, and grow your influence
              </p>
              <Button
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700"
                onClick={() => (window.location.href = "/create-profile")}
              >
                create your profile
              </Button>
            </Card>

            <Card className="p-8">
              <h3 className="text-xl font-medium mb-4">for brands</h3>
              <p className="text-gray-600 mb-6">
                discover authentic creators and build meaningful partnerships
              </p>
              <Button
                variant="outline"
                className="w-full border-black text-black hover:bg-black hover:text-white"
              >
                find creators
              </Button>
            </Card>
          </div>
        </div>
      </section>

      <Separator className="max-w-6xl mx-auto" />

      {/* Footer */}
      <footer className="py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-6 h-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                  <Users className="w-3 h-3 text-white" />
                </div>
                <span className="font-medium">InfluenceHub</span>
              </div>
              <p className="text-sm text-gray-600">
                connecting authentic creators with meaningful brands
              </p>
            </div>

            <div>
              <h4 className="font-medium mb-4">platform</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <a href="#" className="block hover:text-black">
                  discover creators
                </a>
                <a href="#" className="block hover:text-black">
                  pricing
                </a>
                <a href="#" className="block hover:text-black">
                  success stories
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-4">resources</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <a href="#" className="block hover:text-black">
                  blog
                </a>
                <a href="#" className="block hover:text-black">
                  help center
                </a>
                <a href="#" className="block hover:text-black">
                  creator toolkit
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-4">company</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <a href="#" className="block hover:text-black">
                  about
                </a>
                <a href="#" className="block hover:text-black">
                  careers
                </a>
                <a href="#" className="block hover:text-black">
                  contact
                </a>
              </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-500">
              © 2024 InfluenceHub. all rights reserved.
            </p>
            <div className="flex items-center space-x-6 text-sm text-gray-500 mt-4 md:mt-0">
              <a href="#" className="hover:text-black">
                privacy
              </a>
              <a href="#" className="hover:text-black">
                terms
              </a>
              <a href="#" className="hover:text-black">
                cookies
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
